# UCJC - Sistema de Gestión de Horarios Académicos (V2)

## Instalación

```bash
python -m venv .venv
source .venv/bin/activate  # En Windows: .venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

## Novedades en V2

- **Autenticación completa**: Login/logout con redirección a `/login/`.
- **Control de roles (RBAC)**: Cada usuario tiene un perfil con rol (DEAN, PROF, STUD, IT, CONS).
- **Vistas de horario visual**: Tabla lunes–viernes con franjas horarias filtrable por titulación y curso.
- **Workflow de horarios**: Flujo DRAFT → REVIEW → APPROVED/REJECTED.
- **Disponibilidad docente**: Interfaz para que el profesorado marque franjas preferentes/bloqueadas.
- **Formularios web**: Crear horarios y ofertas de asignatura desde la interfaz.
- **Sidebar de navegación**: Acceso rápido a todas las secciones.
- **Indicador de asignaturas transversales** (compartidas entre titulaciones).

## Estructura

```
config/         configuración del proyecto
horarios/       app principal
  models.py     entidades del dominio (sin cambios desde V1)
  views.py      vistas con control de acceso por rol
  forms.py      formularios con validación
  urls.py       rutas de la aplicación
  templates/    plantillas HTML con Bootstrap 5
  templatetags/ filtros personalizados
```

## Roles disponibles

| Rol    | Descripción             | Acceso                              |
|--------|-------------------------|-------------------------------------|
| DEAN   | Decanato                | Gestión completa, aprobar/rechazar  |
| PROF   | Profesor                | Ver horarios, gestionar disponibilidad |
| STUD   | Estudiante              | Consultar horarios propios          |
| IT     | Departamento TI         | Gestión técnica                     |
| CONS   | Consultor               | Solo lectura                        |

## Datos de prueba

Añade datos desde el panel de administración en `/admin/`:
1. Crear `AcademicYear` (ej: 2025-26)
2. Crear `DegreeProgram` (ej: GII)
3. Crear `Course`, `Professor`, `Classroom`, `Subject`
4. Crear `TimeSlotConfig` para el año académico
5. Crear `SubjectOffering` y `Schedule`
