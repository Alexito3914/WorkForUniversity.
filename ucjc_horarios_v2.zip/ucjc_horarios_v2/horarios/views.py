"""
Views principales del sistema de gestión de horarios UCJC.

Cada vista requiere autenticación. El acceso a ciertas vistas
está restringido según el rol del usuario (RBAC - RNF-07).
"""

from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.shortcuts import render, get_object_or_404, redirect
from django.db.models import Count

from .models import (
    Course, DegreeProgram, Professor, Schedule,
    Subject, SubjectOffering, ScheduleEntry, UserProfile,
    AcademicYear, TimeSlotConfig, Enrollment
)
from .forms import ScheduleForm, SubjectOfferingForm, ProfessorAvailabilityForm


def _get_user_role(request):
    """Devuelve el rol del usuario autenticado, o None si no tiene perfil."""
    try:
        return request.user.userprofile.role
    except UserProfile.DoesNotExist:
        return None


@login_required
def home(request):
    """
    Vista principal / home del sistema.
    Muestra métricas generales del sistema (RF-01, RF-07).
    """
    role = _get_user_role(request)
    context = {
        'total_titulaciones': DegreeProgram.objects.filter(is_active=True).count(),
        'total_cursos': Course.objects.count(),
        'total_profesores': Professor.objects.count(),
        'total_horarios': Schedule.objects.count(),
        'horarios_draft': Schedule.objects.filter(status='DRAFT').count(),
        'horarios_review': Schedule.objects.filter(status='REVIEW').count(),
        'horarios_approved': Schedule.objects.filter(status='APPROVED').count(),
        'user_role': role,
    }
    return render(request, 'horarios/home.html', context)


@login_required
def dashboard(request):
    """
    Dashboard académico con resumen de horarios y titulaciones.
    Accesible a todos los roles autenticados.
    """
    schedules = Schedule.objects.select_related('academic_year').all()[:10]
    degrees = DegreeProgram.objects.filter(is_active=True)
    context = {
        'schedules': schedules,
        'degrees': degrees,
        'user_role': _get_user_role(request),
    }
    return render(request, 'horarios/dashboard.html', context)


@login_required
def schedule_list(request):
    """
    Lista de todos los horarios con su estado de workflow (RF-04).
    El Decanato puede aprobar/rechazar; otros roles solo consultan.
    """
    role = _get_user_role(request)
    schedules = Schedule.objects.select_related('academic_year').order_by('-created_at')
    context = {
        'schedules': schedules,
        'user_role': role,
        'can_manage': role in ('DEAN', 'IT'),
    }
    return render(request, 'horarios/schedule_list.html', context)


@login_required
def schedule_detail(request, pk):
    """
    Detalle de un horario con tabla visual por días/franjas (RF-09, RF-U09).
    Muestra las entradas organizadas en una cuadrícula lunes-viernes.
    """
    schedule = get_object_or_404(Schedule, pk=pk)
    role = _get_user_role(request)

    # Filtros opcionales por titulación o curso
    degree_filter = request.GET.get('degree')
    course_filter = request.GET.get('course')

    entries_qs = schedule.entries.select_related(
        'subject_offering__subject',
        'subject_offering__professor',
        'subject_offering__classroom',
        'subject_offering__course__degree_program',
        'timeslot',
    )

    if degree_filter:
        entries_qs = entries_qs.filter(
            subject_offering__course__degree_program_id=degree_filter
        )
    if course_filter:
        entries_qs = entries_qs.filter(
            subject_offering__course_id=course_filter
        )

    # Construir estructura para tabla visual
    day_order = ['MON', 'TUE', 'WED', 'THU', 'FRI']
    day_labels = {'MON': 'Lunes', 'TUE': 'Martes', 'WED': 'Miércoles',
                  'THU': 'Jueves', 'FRI': 'Viernes'}
    timeslots = TimeSlotConfig.objects.filter(
        academic_year=schedule.academic_year, is_active=True
    ).order_by('start_time')

    # Mapa: {day: {timeslot_id: [entries]}}
    timetable = {day: {ts.pk: [] for ts in timeslots} for day in day_order}
    for entry in entries_qs:
        d = entry.timeslot.day_of_week
        ts_id = entry.timeslot.pk
        if d in timetable and ts_id in timetable[d]:
            timetable[d][ts_id].append(entry)

    degrees = DegreeProgram.objects.filter(is_active=True)
    courses = Course.objects.select_related('degree_program').all()

    context = {
        'schedule': schedule,
        'timetable': timetable,
        'day_order': day_order,
        'day_labels': day_labels,
        'timeslots': timeslots,
        'degrees': degrees,
        'courses': courses,
        'selected_degree': degree_filter,
        'selected_course': course_filter,
        'user_role': role,
        'can_manage': role in ('DEAN', 'IT'),
    }
    return render(request, 'horarios/schedule_detail.html', context)


@login_required
def schedule_create(request):
    """
    Crear un nuevo horario (RF-01). Solo DEAN e IT pueden crear.
    """
    role = _get_user_role(request)
    if role not in ('DEAN', 'IT'):
        messages.error(request, 'No tienes permisos para crear horarios.')
        return redirect('horarios:schedule_list')

    if request.method == 'POST':
        form = ScheduleForm(request.POST)
        if form.is_valid():
            schedule = form.save(commit=False)
            schedule.status = 'DRAFT'
            schedule.save()
            messages.success(request, f'Horario "{schedule.name}" creado como borrador.')
            return redirect('horarios:schedule_detail', pk=schedule.pk)
    else:
        form = ScheduleForm()

    return render(request, 'horarios/schedule_form.html', {'form': form, 'action': 'Crear'})


@login_required
def schedule_workflow(request, pk, action):
    """
    Gestión del workflow de horarios: enviar a revisión, aprobar o rechazar (RF-04).
    Solo el Decanato puede aprobar/rechazar.
    """
    schedule = get_object_or_404(Schedule, pk=pk)
    role = _get_user_role(request)

    transitions = {
        'submit':   ('DRAFT',    'REVIEW',    ['DEAN', 'IT']),
        'approve':  ('REVIEW',   'APPROVED',  ['DEAN']),
        'reject':   ('REVIEW',   'REJECTED',  ['DEAN']),
        'reopen':   ('REJECTED', 'DRAFT',     ['DEAN', 'IT']),
    }

    if action not in transitions:
        messages.error(request, 'Acción no válida.')
        return redirect('horarios:schedule_list')

    required_status, new_status, allowed_roles = transitions[action]
    if role not in allowed_roles:
        messages.error(request, 'No tienes permiso para esta acción.')
    elif schedule.status != required_status:
        messages.error(request, f'El horario no está en estado "{required_status}" para esta acción.')
    else:
        schedule.status = new_status
        schedule.save()
        labels = {'submit': 'enviado a revisión', 'approve': 'aprobado',
                  'reject': 'rechazado', 'reopen': 'reabierto como borrador'}
        messages.success(request, f'Horario "{schedule.name}" {labels[action]}.')

    return redirect('horarios:schedule_list')


@login_required
def professor_availability(request):
    """
    Vista para que el profesorado gestione su disponibilidad horaria (RF-06).
    Acceso restringido al propio profesor, DEAN e IT.
    """
    role = _get_user_role(request)
    if role not in ('PROF', 'DEAN', 'IT'):
        messages.error(request, 'Acceso no autorizado.')
        return redirect('horarios:home')

    # Si es profesor, filtrar por su perfil
    professors = Professor.objects.all()
    selected_professor = None
    if role == 'PROF':
        # Intentar vincular por email
        try:
            selected_professor = Professor.objects.get(email=request.user.email)
        except Professor.DoesNotExist:
            pass
    else:
        prof_id = request.GET.get('professor')
        if prof_id:
            selected_professor = get_object_or_404(Professor, pk=prof_id)

    availabilities = []
    timeslots = []
    if selected_professor:
        timeslots = TimeSlotConfig.objects.filter(is_active=True).order_by('day_of_week', 'start_time')
        availabilities = selected_professor.availabilities.select_related('timeslot').all()

    if request.method == 'POST' and selected_professor:
        form = ProfessorAvailabilityForm(request.POST, professor=selected_professor)
        if form.is_valid():
            form.save()
            messages.success(request, 'Disponibilidad actualizada correctamente.')
            return redirect(request.path + f'?professor={selected_professor.pk}')
    else:
        form = ProfessorAvailabilityForm(professor=selected_professor) if selected_professor else None

    context = {
        'professors': professors,
        'selected_professor': selected_professor,
        'availabilities': availabilities,
        'timeslots': timeslots,
        'form': form,
        'user_role': role,
    }
    return render(request, 'horarios/professor_availability.html', context)


@login_required
def subject_offering_create(request):
    """
    Crear una oferta de asignatura (asignar profesor+aula a asignatura+curso).
    Solo DEAN e IT (RF-01, RF-U05).
    """
    role = _get_user_role(request)
    if role not in ('DEAN', 'IT'):
        messages.error(request, 'No tienes permisos para esta acción.')
        return redirect('horarios:dashboard')

    if request.method == 'POST':
        form = SubjectOfferingForm(request.POST)
        if form.is_valid():
            offering = form.save()
            messages.success(request, f'Oferta "{offering}" creada correctamente.')
            return redirect('horarios:dashboard')
    else:
        form = SubjectOfferingForm()

    return render(request, 'horarios/subject_offering_form.html', {
        'form': form,
        'action': 'Crear oferta de asignatura',
    })


@login_required
def degree_list(request):
    """
    Lista de titulaciones activas con sus cursos y asignaturas (RF-09.2).
    """
    degrees = DegreeProgram.objects.filter(is_active=True).prefetch_related(
        'courses__subject_offerings__subject',
        'courses__subject_offerings__professor',
    )
    context = {
        'degrees': degrees,
        'user_role': _get_user_role(request),
    }
    return render(request, 'horarios/degree_list.html', context)
