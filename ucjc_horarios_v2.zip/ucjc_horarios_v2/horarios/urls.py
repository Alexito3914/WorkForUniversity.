from django.urls import path
from . import views

app_name = 'horarios'

urlpatterns = [
    path('', views.home, name='home'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('titulaciones/', views.degree_list, name='degree_list'),
    path('horarios/', views.schedule_list, name='schedule_list'),
    path('horarios/nuevo/', views.schedule_create, name='schedule_create'),
    path('horarios/<int:pk>/', views.schedule_detail, name='schedule_detail'),
    path('horarios/<int:pk>/workflow/<str:action>/', views.schedule_workflow, name='schedule_workflow'),
    path('disponibilidad/', views.professor_availability, name='professor_availability'),
    path('ofertas/nueva/', views.subject_offering_create, name='subject_offering_create'),
]
