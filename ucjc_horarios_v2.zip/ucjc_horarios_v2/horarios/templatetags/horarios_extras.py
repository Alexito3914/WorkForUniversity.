"""Filtros de template personalizados para el sistema de horarios."""
from django import template

register = template.Library()

@register.filter
def get_item(dictionary, key):
    """Permite acceder a valores de un diccionario con una variable como clave."""
    return dictionary.get(key)
