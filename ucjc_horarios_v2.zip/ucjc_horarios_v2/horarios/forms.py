"""
Formularios del sistema de gestión de horarios UCJC.
Implementan validación de restricciones de dominio (RF-02, RD-05, RD-12).
"""

from django import forms
from django.core.exceptions import ValidationError

from .models import (
    Schedule, SubjectOffering, ProfessorAvailability,
    TimeSlotConfig, Professor, ScheduleEntry
)


class ScheduleForm(forms.ModelForm):
    """Formulario para crear/editar un horario académico (RF-01)."""

    class Meta:
        model = Schedule
        fields = ['name', 'academic_year']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej: Horario 2025-26 Primer Semestre'}),
            'academic_year': forms.Select(attrs={'class': 'form-select'}),
        }
        labels = {
            'name': 'Nombre del horario',
            'academic_year': 'Año académico',
        }


class SubjectOfferingForm(forms.ModelForm):
    """
    Formulario para crear una oferta de asignatura.
    Valida que el profesor no tenga conflictos de disponibilidad (RF-02, RD-05).
    """

    class Meta:
        model = SubjectOffering
        fields = ['subject', 'course', 'professor', 'classroom', 'group_name']
        widgets = {
            'subject': forms.Select(attrs={'class': 'form-select'}),
            'course': forms.Select(attrs={'class': 'form-select'}),
            'professor': forms.Select(attrs={'class': 'form-select'}),
            'classroom': forms.Select(attrs={'class': 'form-select'}),
            'group_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej: Grupo A'}),
        }
        labels = {
            'subject': 'Asignatura',
            'course': 'Curso',
            'professor': 'Profesor responsable',
            'classroom': 'Aula asignada',
            'group_name': 'Nombre del grupo',
        }


class ProfessorAvailabilityForm(forms.Form):
    """
    Formulario para que el profesorado registre su disponibilidad (RF-06).
    Permite marcar cada franja como preferente, bloqueada o sin definir.
    """
    STATUS_CHOICES = [
        ('', '— Sin definir —'),
        ('PREFERRED', 'Disponibilidad preferente'),
        ('BLOCKED', 'Indisponibilidad'),
    ]

    def __init__(self, *args, professor=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.professor = professor
        if professor:
            timeslots = TimeSlotConfig.objects.filter(is_active=True).order_by('day_of_week', 'start_time')
            existing = {a.timeslot_id: a.status for a in professor.availabilities.all()}
            for ts in timeslots:
                field_name = f'ts_{ts.pk}'
                self.fields[field_name] = forms.ChoiceField(
                    choices=self.STATUS_CHOICES,
                    required=False,
                    initial=existing.get(ts.pk, ''),
                    label=str(ts),
                    widget=forms.Select(attrs={'class': 'form-select form-select-sm'}),
                )

    def save(self):
        """Guarda o elimina las disponibilidades según la selección del formulario."""
        if not self.professor:
            return
        for field_name, value in self.cleaned_data.items():
            if not field_name.startswith('ts_'):
                continue
            ts_id = int(field_name.split('_')[1])
            ts = TimeSlotConfig.objects.get(pk=ts_id)
            if value:
                ProfessorAvailability.objects.update_or_create(
                    professor=self.professor,
                    timeslot=ts,
                    defaults={'status': value},
                )
            else:
                ProfessorAvailability.objects.filter(
                    professor=self.professor, timeslot=ts
                ).delete()
