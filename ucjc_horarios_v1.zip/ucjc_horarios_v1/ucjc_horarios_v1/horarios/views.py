from django.shortcuts import render
from .models import Course, DegreeProgram, Professor, Schedule


def home(request):
    context = {
        'total_titulaciones': DegreeProgram.objects.count(),
        'total_cursos': Course.objects.count(),
        'total_profesores': Professor.objects.count(),
        'total_horarios': Schedule.objects.count(),
    }
    return render(request, 'horarios/home.html', context)


def dashboard(request):
    context = {
        'schedules': Schedule.objects.select_related('academic_year').all()[:10],
        'degrees': DegreeProgram.objects.all()[:10],
    }
    return render(request, 'horarios/dashboard.html', context)
