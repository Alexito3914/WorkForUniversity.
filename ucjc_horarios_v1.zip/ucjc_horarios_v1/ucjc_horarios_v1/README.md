# UCJC - Sistema de Gestión de Horarios Académicos (V1)

## Instalación

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

## Qué incluye esta versión

- Modelado inicial del dominio en Django.
- Home principal `/`.
- URL adicional `/dashboard/` con otra template.
- Integración de `django-debug-toolbar` en `__debug__/`.
- Uso del panel de administración de Django para cargar datos iniciales.

## Estructura principal

- `config/`: configuración del proyecto.
- `horarios/`: app principal.
- `horarios/models.py`: entidades y relaciones.
- `horarios/views.py`: vistas de la home y dashboard.
- `horarios/templates/horarios/`: templates HTML.

## Entidades principales

- Titulación
- Año académico
- Curso
- Profesor
- Estudiante
- Asignatura
- Oferta de asignatura
- Aula
- Franja horaria
- Disponibilidad del profesorado
- Horario y entradas de horario
- Matrícula
